/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package created3files;

import com.opencsv.CSVReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author green
 */
public class CreateD3Files {

    final static String programDataFolder = "ProgramData";
    final static String categoryList = "CategoryList.csv";
    static String userDir;
    public static String filePathSymbol;
    private static Map<String, InputCategory> categoriesAndComponents;
    final private static String outputFolder = "/home/green/Desktop/D3/";
    final private static int maxLength = 252;
    final private static int[] windows = {52, 104, 153, 256, 512, 1260, 1764, 2520, 5040, 10080};

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {

        setOperatingSystem();
        userDir = System.getProperty("user.dir");
        categoriesAndComponents = new TreeMap<>();
        
        try {
            System.out.println("Input Location: " + userDir + filePathSymbol + programDataFolder + filePathSymbol + categoryList);
            CSVReader reader = new CSVReader(new FileReader(userDir + filePathSymbol + programDataFolder + filePathSymbol + categoryList));
            List<String[]> myEntries = reader.readAll();

            for (String[] myEntry : myEntries) {
                String categoryName = myEntry[0];
                InputCategory tempInputCategory = new InputCategory(categoryName);
                tempInputCategory.setComponents();
                categoriesAndComponents.put(categoryName, tempInputCategory);
            }
            
        } catch (FileNotFoundException ex) {
            System.out.println("File Not Found Exception. Code 008.");
        } catch (IOException ex) {
            System.out.println("IO Exception. Code 009.");
        }
        

        for (Map.Entry<String, InputCategory> entry : categoriesAndComponents.entrySet()) {
            String category = entry.getKey();
            System.out.println("Creating D3 files for category: " + category);
            InputCategory tempCategory = entry.getValue();
            tempCategory.createD3Files(outputFolder, maxLength, windows);
        }
        
        
        
    }
 
    
        /**
     * 
     */
    public static void setOperatingSystem() {
        if (OSValidator.isWindows()) {
            filePathSymbol = "\\";
        }
        
        else if (OSValidator.isUnix()) {
            filePathSymbol = "/";
        }
        
        else {
            filePathSymbol = "/";
        }
    }
}
